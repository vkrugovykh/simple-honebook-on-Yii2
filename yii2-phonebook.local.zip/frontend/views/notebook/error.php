<?php

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

?>
<div class="site-error">

    <h1>Ошибка!</h1>

    <div class="alert alert-danger">Запись отсутствует</div>

</div>
