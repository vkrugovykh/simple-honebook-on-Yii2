<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm; ?>

<div class="site-index">
    <h1>Телефонный справочник</h1>

    <h2>Для использования справочника требуется авторизация</h2>

    <a href="/user/login" class="btn btn-primary">Войти</a>

    <a href="/user/register" class="btn btn-primary">Регистрация</a>

</div>